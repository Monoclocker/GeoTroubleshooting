import { observer } from "mobx-react-lite";
import MapComponent from "../components/MapComponent";


export const MapPage = observer(() => {

    return (<>
        <MapComponent />
    </>)
})

