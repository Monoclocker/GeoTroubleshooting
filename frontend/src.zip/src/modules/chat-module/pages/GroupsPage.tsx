import GroupCreateForm from "../components/GroupCreateForm"
import Groups from "../components/Groups"

const GroupsPage = () => {

    /*const { id } = useParams()*/


    return <>
        <GroupCreateForm/>
        <Groups/>
    </>
}

export { GroupsPage }