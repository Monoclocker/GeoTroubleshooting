import UserProfile from "../components/UserProfile"

function Profile() {


    return (
        <>
            <UserProfile/>
        </>
    )
}

export { Profile }