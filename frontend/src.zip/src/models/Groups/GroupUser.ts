interface GroupUser {
    username: string
    isAdmin: boolean
}

export default GroupUser