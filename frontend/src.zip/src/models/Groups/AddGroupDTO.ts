interface AddGroupDTO {
    username: string,
    groupId: number
}

export default AddGroupDTO