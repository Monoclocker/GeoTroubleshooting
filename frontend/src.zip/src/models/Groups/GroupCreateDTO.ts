interface GroupCreateDTO {
    name: string
    description?: string 
    placeId: number
    username: string
}
export default GroupCreateDTO