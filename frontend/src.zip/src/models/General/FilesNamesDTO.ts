interface FilesNamesDTO {
    filesNames: string[]
}

export default FilesNamesDTO