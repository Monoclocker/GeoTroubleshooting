interface Attachment {
    type: string,
    path: string
}

export default Attachment