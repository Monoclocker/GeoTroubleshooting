import { LngLat } from "@yandex/ymaps3-types"

interface MapLocation {
    center: LngLat
    zoom: number 
}

export default MapLocation