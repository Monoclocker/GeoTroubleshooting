interface RolesDTO {
    id: number,
    name: string
}

export default RolesDTO