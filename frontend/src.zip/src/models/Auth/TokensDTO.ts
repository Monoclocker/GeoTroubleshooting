interface TokensDTO {
    accessToken?: string,
    refreshToken?: string
}

export default TokensDTO