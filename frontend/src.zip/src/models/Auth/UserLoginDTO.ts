interface UserLoginDTO {
    username: string,
    password: string
}

export default UserLoginDTO