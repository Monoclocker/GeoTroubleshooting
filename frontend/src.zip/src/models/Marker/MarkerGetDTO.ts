interface MarkersGetDTO {
    startTimeStamp: number,
    endTimeStamp: number,
    placeId: number,
    markerId?: string
}

export default MarkersGetDTO