interface PlaceDTO {
    id: number
    name: string
    typeId: number
    coordinates: number[]
}

export default PlaceDTO